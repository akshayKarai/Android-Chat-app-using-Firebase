

import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;

public class ThreadActivity extends AppCompatActivity {

    TextView username;
    EditText newThread;

    String UserName ="";

    ListView threadsList;
    Button signout, addThread;
    private FirebaseAuth mAuth;
    private FirebaseDatabase database;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_thread);
        this.setTitle("Message Threads");
        signout = findViewById(R.id.buttonSignout);
        addThread = findViewById(R.id.buttonAddThread);

        username = findViewById(R.id.textViewUserName);
        newThread = findViewById(R.id.addChatMessageET);

        threadsList = findViewById(R.id.listViewChats);


        database = FirebaseDatabase.getInstance();
        mAuth = FirebaseAuth.getInstance();

        UserName = mAuth.getCurrentUser().getDisplayName();
        if(!UserName.isEmpty()) {
            username.setText(UserName);
        }
        else
        {
            username.setText("no UserName");
        }


        signout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(ThreadActivity.this, MainActivity.class);
                mAuth.signOut();
                startActivity(intent);
                finish();
            }
        });

        addThread.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(!newThread.getText().toString().isEmpty()){
                    addThread(newThread.getText().toString());
                    newThread.setText("");
                }
            }
        });

        database.getReference().child("threads").addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                Iterable iterable = dataSnapshot.getChildren();
                final List<Thread> t = new ArrayList<Thread>();
                while(iterable.iterator().hasNext()){
                    DataSnapshot ds = (DataSnapshot)iterable.iterator().next();
                    String tid = ds.child("threadID").getValue().toString();

                    String title = ds.child("title").getValue().toString();

                    String username = ds.child("username").getValue().toString();
                    String uid = ds.child("userID").getValue().toString();
                    t.add(new Thread(tid, username, uid, title));
                }
                ThreadsAdapter threadsAdapter = new ThreadsAdapter(ThreadActivity.this, R.layout.display_thread, t, getToken());
                threadsList.setAdapter(threadsAdapter);
                threadsList.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                    @Override
                    public void onItemClick(AdapterView<?> adapterView, View view, int position, long l) {
                        Intent intent = new Intent(ThreadActivity.this, ChatroomActivity.class);





                        intent.putExtra("thread", t.get(position));
                        Thread titem=t.get(position);
                        intent.putExtra("threadID","1");


                        intent.putExtra("threadid",titem);
                        startActivity(intent);
                    }
                });
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {

            }
        });
    }

    public void addThread(String thread_name){
        Thread thread = new Thread("", mAuth.getCurrentUser().getDisplayName(), getToken(), thread_name);
        DatabaseReference newRef = database.getReference().child("threads").push();

        Task t = newRef.setValue(thread);

        t.addOnCompleteListener(new OnCompleteListener() {
            @Override
            public void onComplete(@NonNull Task task) {
                if(task.isSuccessful()){
                    Toast.makeText(ThreadActivity.this, "Successful", Toast.LENGTH_SHORT).show();
                }
                else{
                    Toast.makeText(ThreadActivity.this, "UnSuccessful", Toast.LENGTH_SHORT).show();
                }
            }
        });

        newRef.child("threadID").setValue(newRef.getKey());
    }

    public String getToken(){
        return mAuth.getCurrentUser().getUid();
    }
}

