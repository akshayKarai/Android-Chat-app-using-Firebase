

import java.io.Serializable;



public class Thread implements Serializable {
    String threadID, username, userID, title;

    public Thread(){

    }

    public Thread(String threadID, String username, String userID, String title){
        this.threadID = threadID;
        this.username = username;
        this.userID = userID;
        this.title = title;
    }

    public String getThreadID(){
        return threadID;
    }

    public String getUsername() {
        return username;
    }

    public String getUserID() {
        return userID;
    }

    public String getTitle() {
        return title;
    }
}

