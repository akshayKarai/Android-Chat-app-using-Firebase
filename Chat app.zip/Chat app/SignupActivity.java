

import android.content.Intent;
import android.content.SharedPreferences;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.UserProfileChangeRequest;
import com.google.firebase.database.FirebaseDatabase;

public class SignupActivity extends AppCompatActivity {

    EditText fname, lname, email;
    EditText pass, repass;
    Button cancel, signupButton;

    SharedPreferences sharedPreferences;

    private FirebaseAuth mAuth;
    private FirebaseDatabase database;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_signup);
        this.setTitle("Sign Up");
        fname = findViewById(R.id.signupFName);
        lname = findViewById(R.id.signupLName);
        email = findViewById(R.id.signupEmail);
        pass = findViewById(R.id.signupPassword);
        repass = findViewById(R.id.signupRPassword);
        cancel = findViewById(R.id.buttonCancel);
        signupButton = findViewById(R.id.buttonToSignUp);
        mAuth = FirebaseAuth.getInstance();
        database = FirebaseDatabase.getInstance();


        signupButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(fname.getText().toString().isEmpty() || lname.getText().toString().isEmpty() || email.getText().toString().isEmpty() || pass.getText().toString().isEmpty() || repass.getText().toString().isEmpty()){
                    Toast.makeText(SignupActivity.this, "Fill in all fields", Toast.LENGTH_SHORT).show();
                }
                else if(!pass.getText().toString().equals(repass.getText().toString())){
                    Toast.makeText(SignupActivity.this, "Password fields do not match", Toast.LENGTH_SHORT).show();
                }
                else if(pass.getText().toString().length() < 6){
                    Toast.makeText(SignupActivity.this, "Password must be at least 6 characters", Toast.LENGTH_SHORT).show();
                }
                else{
                    performSignup(email.getText().toString(), pass.getText().toString(), fname.getText().toString(), lname.getText().toString());
                }
            }
        });

        cancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(SignupActivity.this, MainActivity.class);

                startActivity(intent);
                finish();
            }
        });

    }

    public void performSignup(String email, String password, String fname, String lname){
        final User user = new User(fname, lname, email, password);
        mAuth.createUserWithEmailAndPassword(email, password).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
            @Override
            public void onComplete(@NonNull Task<AuthResult> task) {
                if (task.isSuccessful()) {

                    database.getReference().child("users").push().setValue(user);

                    UserProfileChangeRequest profileUpdates = new UserProfileChangeRequest.Builder()
                            .setDisplayName(user.getFirst() + " " + user.getLast()).build();
                    mAuth.getCurrentUser().updateProfile(profileUpdates).addOnCompleteListener(new OnCompleteListener<Void>() {
                        @Override
                        public void onComplete(@NonNull Task<Void> task) {
                            if(task.isSuccessful()){

                            }
                            else{

                            }
                            Toast.makeText(SignupActivity.this, "Signup is successful", Toast.LENGTH_SHORT).show();
                            mAuth.signInWithEmailAndPassword(user.getEmail(), user.getPassword());
                            Intent intent = new Intent(SignupActivity.this, ThreadActivity.class);
                            startActivity(intent);

                        }
                    });
                } else {

                    Toast.makeText(SignupActivity.this, task.getException().getMessage(),
                            Toast.LENGTH_SHORT).show();
                }
            }
        });
    }
}

