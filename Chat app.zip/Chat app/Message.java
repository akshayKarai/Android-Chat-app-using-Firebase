

import java.io.Serializable;



public class Message implements Serializable {
    String username, user_id, mid, message, created_at;



    public Message(String username, String user_id, String mid, String message, String created_at) {
        this.username = username;
        this.user_id = user_id;
        this.mid = mid;
        this.message = message;
        this.created_at = created_at;
    }

    public Message() {

    }

    public String getUsername() {
        return username;
    }

    public String getUser_id() {
        return user_id;
    }

    public String getMid() {
        return mid;
    }

    public String getMessage() {
        return message;
    }

    public String getCreated_at() {
        return created_at;
    }
}


