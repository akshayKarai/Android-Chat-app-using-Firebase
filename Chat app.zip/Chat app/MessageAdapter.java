

import android.content.Context;
import android.os.Build;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.annotation.RequiresApi;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.TextView;

import com.google.firebase.database.FirebaseDatabase;

import org.ocpsoft.prettytime.PrettyTime;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.List;
import java.util.TimeZone;

/**
 * Created by akshay on 4/21/18.
 */

public class MessageAdapter extends ArrayAdapter<Message> {
    String uID;
    Thread threadobject;


    private FirebaseDatabase database;


    public MessageAdapter(@NonNull Context context, int resource, @NonNull List<Message> objects, String userid, Thread thread) {
        super(context, resource, objects);
        uID = userid;
        threadobject =thread;
        database=FirebaseDatabase.getInstance();
    }

    @RequiresApi(api = Build.VERSION_CODES.O)
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        MessageAdapter.ViewHolder viewHolder;
        final Message message=getItem(position);
        PrettyTime prettyTime = new PrettyTime();
        DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");
        dateFormat.setTimeZone(TimeZone.getTimeZone("EST"));

        if (convertView==null)
        {
            convertView= LayoutInflater.from(getContext()).inflate(R.layout.display_message,parent,false);
            viewHolder=new MessageAdapter.ViewHolder();
            viewHolder.textViewAuthor= convertView.findViewById(R.id.Authortv);
            viewHolder.buttonDeleteMessage = convertView.findViewById(R.id.buttonDeleteMessage);
            viewHolder.textViewMessage= convertView.findViewById(R.id.Messagetv);
            viewHolder.textViewMessageTime= convertView.findViewById(R.id.MessageTimetv);
            convertView.setTag(viewHolder);
        }
        else
        {
            viewHolder= (MessageAdapter.ViewHolder) convertView.getTag();
        }

        String date = "";
        try {
            date = prettyTime.format(dateFormat.parse(message.getCreated_at()));
        } catch (ParseException e) {
            e.printStackTrace();

        }
        viewHolder.textViewMessage.setText(message.getMessage());
        viewHolder.textViewMessageTime.setText(date);
        viewHolder.textViewAuthor.setText(message.getUsername());
        if (message.getUser_id().equals(uID)) {
            viewHolder.buttonDeleteMessage.setVisibility(View.VISIBLE);
            viewHolder.buttonDeleteMessage.setFocusable(false);

            viewHolder.buttonDeleteMessage.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    database.getReference().child("threads").child(threadobject.getThreadID()).child("messages").child(message.getMid()).setValue(null);

                }
            });
        }
        else
        {
            viewHolder.buttonDeleteMessage.setVisibility(View.GONE);
        }
        notifyDataSetChanged();
        return convertView;
    }

    private static class ViewHolder
    {
        TextView textViewAuthor, textViewMessage, textViewMessageTime;
        Button buttonDeleteMessage;
    }
}
