



import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.TimeZone;

public class ChatroomActivity extends AppCompatActivity {

    private final int KEY = 111;
    Thread threaditem;

    ListView messagesList;

    private FirebaseAuth mAuth;
    private FirebaseDatabase database;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_chatroom);
        this.setTitle("Chat Room");
        TextView threadname=findViewById(R.id.ThreadNameTV);
        final EditText my_message = findViewById(R.id.addChatMessageET);
        messagesList = findViewById(R.id.listViewChats);
        if(getIntent().getExtras().getString("threadID","0").equals("1")) {

            threaditem = (Thread) getIntent().getExtras().getSerializable("threadid");

        }
        threadname.setText(threaditem.getTitle());
        mAuth = FirebaseAuth.getInstance();
        database = FirebaseDatabase.getInstance();

        if(getIntent().getExtras().getString("msgdel","0").equals("1"))
        {
            Toast.makeText(this, "Your Message is Deleted", Toast.LENGTH_LONG).show();

        }
        Button back =findViewById(R.id.backThreadbutton);
        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(ChatroomActivity.this, ThreadActivity.class);

                startActivity(intent);
                finish();
            }
        });

        Button add_message = findViewById(R.id.addMessageButton);
        add_message.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(!my_message.getText().toString().isEmpty()){
                    addMessage(my_message.getText().toString());
                    my_message.setText("");
                }
            }
        });

        database.getReference().child("threads").child(threaditem.threadID).child("messages").addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                Iterable iterable = dataSnapshot.getChildren();
                final List<Message> m = new ArrayList<Message>();
                while(iterable.iterator().hasNext()){
                    DataSnapshot ds = (DataSnapshot)iterable.iterator().next();
                    String username = ds.child("username").getValue().toString();



                    String uid = ds.child("userID").getValue().toString();

                    String mid = ds.child("mid").getValue().toString();
                    String message = ds.child("message").getValue().toString();


                    String created_at = ds.child("created_at").getValue().toString();
                    m.add(new Message(username, uid, mid, message, created_at));
                }
                MessageAdapter messageAdapter = new MessageAdapter(ChatroomActivity.this, R.layout.display_message, m, getToken(), threaditem);
                messagesList.setAdapter(messageAdapter);
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {

            }
        });
    }

    public void addMessage(String new_message){
        Date d = new Date();
        DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");
        dateFormat.setTimeZone(TimeZone.getTimeZone("EST"));
        String date = dateFormat.format(d);


        Message message = new Message(mAuth.getCurrentUser().getDisplayName(), getToken(), "", new_message, date);
        DatabaseReference newRef = database.getReference().child("threads").child(threaditem.threadID).child("messages").push();
        newRef.setValue(message);

        newRef.child("mid").setValue(newRef.getKey());
    }

    public String getToken(){
        return mAuth.getCurrentUser().getUid();
    }
}
